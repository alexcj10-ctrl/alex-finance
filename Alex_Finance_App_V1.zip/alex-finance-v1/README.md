# Alex Finance V1

Mini app mobile per il controllo quotidiano della cassa e delle commissioni Tecnocasa.

## Funzioni
- Cassa: Banca, Revolut e contanti
- Movimento rapido: spesa, entrata, trasferimento
- Commissioni: Da fare, In trattativa, Incassata, Annullata
- Check settimanale
- KPI automatici: runway, margine, commissione mancante, extra
- Dati salvati sul dispositivo via localStorage

## Pubblicazione su Vercel
1. Carica questi file in un repository GitHub.
2. Vercel → Add New → Project → importa il repository.
3. Deploy.
4. Su iPhone: Safari → Condividi → Aggiungi a schermata Home.

Questa V1 non sincronizza tra dispositivi: la V2 userà accesso privato e database.
